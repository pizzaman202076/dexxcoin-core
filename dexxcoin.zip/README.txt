put dexxcoin in appdata roaming make a new folder called DexxCoin past config in there


 the rest leave in same folder wherever